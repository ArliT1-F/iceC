# iceC Discord Bot
A discord bot template im working on as I explore the mystical lands of discord.py

I will be adding stuff bit by bit, day by day. 
